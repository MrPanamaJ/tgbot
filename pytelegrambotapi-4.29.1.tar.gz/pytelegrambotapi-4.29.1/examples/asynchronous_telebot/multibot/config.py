MAIN_BOT_TOKEN = "your_main_bot_token"

WEBHOOK_HOST = "your_domain.com"
WEBHOOK_PATH = "telegram_webhook"
WEBAPP_HOST = "0.0.0.0"
WEBAPP_PORT = 3500
